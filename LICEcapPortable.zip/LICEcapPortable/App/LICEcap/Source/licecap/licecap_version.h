#define LICECAP_VERSION "v1.2"
