//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by licecap.rc
//
#define IDD_DIALOG1                     101
#define IDI_ICON1                       103
#define IDD_SAVEOPTS                    104
#define IDD_INSERT                      105
#define IDC_BROWSE                      1000
#define IDC_REC                         1001
#define IDC_STOP                        1002
#define IDC_STATUS                      1003
#define IDC_MAXFPS_LBL                  1004
#define IDC_MAXFPS                      1005
#define IDC_VIEWRECT                    1006
#define IDC_TITLEUSE                    1007
#define IDC_BIGFONT                     1008
#define IDC_XSZ                         1008
#define IDC_MS                          1009
#define IDC_YSZ                         1009
#define IDC_TITLE                       1010
#define IDC_MOUSECAP                    1011
#define IDC_TIMELINE                    1012
#define IDC_SSPAUSE                     1013
#define IDC_DIMLBL                      1014
#define IDC_DIMLBL_1                    1015
#define IDC_INSERT                      1016
#define IDC_EDIT                        1017
#define IDC_ALPHA                       1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
